function show(msg) {
  alert(msg);
}
//callBack();
//hello();
show('Hi!');
